// script.js
// Máscaras e interatividade podem ser adicionadas aqui no futuro
